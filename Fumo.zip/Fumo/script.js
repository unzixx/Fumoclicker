
document.getElementById('myImage').addEventListener('click', playSound);
function playSound() {
  const audio = new Audio('boop.mp3');
  audio.play();
}